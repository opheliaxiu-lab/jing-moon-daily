import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import { motion } from "framer-motion";
import { Moon, Flower2, CheckCircle2, Briefcase, Sparkles, Heart, NotebookPen, Coffee, BellRing, Droplets } from "lucide-react";
import "./style.css";

const todayText = new Intl.DateTimeFormat("zh-TW", { month: "long", day: "numeric", weekday: "long" }).format(new Date());

const initialTasks = [
  { id: 1, label: "完成一件最重要的公文", group: "工作", done: false },
  { id: 2, label: "喝水、吃藥、讓身體慢一點", group: "身體", done: false },
  { id: 3, label: "地藏經 / 楞嚴心咒 / 迴向姍姍", group: "靈性", done: false },
  { id: 4, label: "整理一張月白靜物照片或文案", group: "月白靜物", done: false },
];

const gentlePrompts = [
  "今天不需要很厲害，只要安穩地完成一小步。",
  "先照顧自己，再處理世界。",
  "妳可以慢一點，事情仍然會一件一件完成。",
  "把力氣留給真正重要的人與事。",
];

function App() {
  const [tasks, setTasks] = useState(initialTasks);
  const [note, setNote] = useState("");
  const [mood, setMood] = useState("平靜");
  const [timer, setTimer] = useState("25");
  const [period, setPeriod] = useState({ startDate: "", flow: "普通", pain: "輕微", note: "" });
  const [water, setWater] = useState({ morning: false, afternoon: false });

  const completed = tasks.filter((task) => task.done).length;
  const progress = Math.round((completed / tasks.length) * 100);
  const prompt = useMemo(() => gentlePrompts[new Date().getDate() % gentlePrompts.length], []);

  const toggleTask = (id) => {
    setTasks((current) => current.map((task) => (task.id === id ? { ...task, done: !task.done } : task)));
  };

  return (
    <div className="page">
      <div className="container">
        <motion.header initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="hero card">
          <div>
            <p className="muted small">{todayText}</p>
            <h1>靜謐的一日</h1>
            <p className="muted heroText">{prompt}</p>
          </div>
          <div className="iconCircle"><Moon /></div>
        </motion.header>

        <div className="grid mainGrid">
          <section className="card wide">
            <div className="sectionTop">
              <div><h2>今日四件小事</h2><p className="muted small">工作、身體、靈性、品牌，各留一點位置。</p></div>
              <div className="progressText"><strong>{progress}%</strong><span>完成度</span></div>
            </div>
            <div className="bar"><div style={{ width: `${progress}%` }} /></div>
            <div className="taskList">
              {tasks.map((task) => (
                <button key={task.id} onClick={() => toggleTask(task.id)} className="taskBtn">
                  <CheckCircle2 className={task.done ? "done" : "notDone"} />
                  <div><p className={task.done ? "cross" : ""}>{task.label}</p><span>{task.group}</span></div>
                </button>
              ))}
            </div>
          </section>

          <aside className="side">
            <section className="card">
              <div className="titleRow"><Heart /><h2>現在的我</h2></div>
              <div className="buttonGrid">{["平靜", "疲憊", "想哭", "有力氣"].map((item) => <button key={item} className={mood === item ? "selected" : "outline"} onClick={() => setMood(item)}>{item}</button>)}</div>
              <p className="muted small">今天的狀態：{mood}</p>
            </section>
            <section className="card">
              <div className="titleRow"><Coffee /><h2>番茄鐘</h2></div>
              <div className="buttonGrid three">{["15", "25", "40"].map((min) => <button key={min} className={timer === min ? "selected" : "outline"} onClick={() => setTimer(min)}>{min} 分</button>)}</div>
              <p className="muted small">先選一段時間，做完就休息。</p>
            </section>
          </aside>
        </div>

        <section className="grid twoGrid">
          <div className="card">
            <div className="titleRow"><Coffee /><h2>喝水紀錄</h2></div>
            <p className="muted small">不追求喝很多，只提醒自己慢慢補水。</p>
            {[['morning','上午 700ml','上班前半段'],['afternoon','下午 700ml','下班前慢慢喝完']].map(([key,title,sub]) => (
              <button key={key} onClick={() => setWater({ ...water, [key]: !water[key] })} className="waterBtn">
                <div><p>{title}</p><span>{sub}</span></div><CheckCircle2 className={water[key] ? "done" : "notDone"} />
              </button>
            ))}
          </div>
          <div className="card">
            <div className="titleRow"><Droplets /><h2>生理期紀錄</h2></div>
            <p className="muted small">只記錄身體狀態，不追求完美數據。</p>
            <label>開始日期<input type="date" value={period.startDate} onChange={(e)=>setPeriod({...period,startDate:e.target.value})}/></label>
            <div className="twoCols">
              <label>經血量<select value={period.flow} onChange={(e)=>setPeriod({...period,flow:e.target.value})}><option>少量</option><option>普通</option><option>偏多</option><option>很多</option></select></label>
              <label>疼痛感<select value={period.pain} onChange={(e)=>setPeriod({...period,pain:e.target.value})}><option>無</option><option>輕微</option><option>明顯</option><option>需要休息</option></select></label>
            </div>
            <textarea value={period.note} onChange={(e)=>setPeriod({...period,note:e.target.value})} placeholder="腹痛、腰痠、頭痛、情緒低落、想睡……" />
          </div>
        </section>

        <div className="grid cards3">
          <SmallCard icon={<Briefcase />} title="文書模式" text="只挑一件最該處理的公文，不把整天都交給焦慮。" />
          <SmallCard icon={<Sparkles />} title="月白靜物" text="紀錄照片、文案、少量上架，不做大量客服型品牌。" />
          <SmallCard icon={<Flower2 />} title="自我照顧" text="吃藥、保養、伸展、睡覺，都是今天有完成的事。" />
        </div>

        <section className="card">
          <div className="titleRow"><NotebookPen /><h2>靜的日誌</h2></div>
          <textarea value={note} onChange={(e)=>setNote(e.target.value)} placeholder="今天發生了什麼？身體有沒有累？有沒有一件值得感謝的小事？" />
        </section>

        <footer><BellRing />願今天的妳，不必逞強，也能慢慢完成。</footer>
      </div>
    </div>
  );
}

function SmallCard({ icon, title, text }) { return <section className="card smallCard"><div className="iconCircle smallIcon">{React.cloneElement(icon, { size: 20 })}</div><h3>{title}</h3><p className="muted small">{text}</p></section>; }

createRoot(document.getElementById("root")).render(<App />);
